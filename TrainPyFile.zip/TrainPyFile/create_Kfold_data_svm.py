# -*- coding: utf-8 -*-
# author - U63411
from numpy.random import seed

seed(1)
import os
from tensorflow.keras import layers
from tensorflow.keras import Model
from tensorflow.keras.layers import BatchNormalization
from tensorflow.keras.optimizers import RMSprop, Adam, SGD
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.regularizers import l2
import numpy as np
from sklearn.model_selection import StratifiedKFold
import pickle
from numpy import save, load
import pandas as pd

base_dir = os.path.join(os.path.dirname(__file__), '../Dataset_all_new')
train_dir = os.path.join(base_dir, 'train')
validation_dir = os.path.join(base_dir, 'validation')
test_dir = os.path.join(base_dir, 'test')

# Directory with our training class1 pictures
train_blank_dir = os.path.join(train_dir, 'Blank')

# Directory with our training class2 pictures
train_cancel_dir = os.path.join(train_dir, 'Cancelled')

# Directory with our training class3 pictures
train_hand_dir = os.path.join(train_dir, 'Handwritten')

# Directory with our training class4 pictures
train_print_dir = os.path.join(train_dir, 'Printed')

# Directory with our validation class1 pictures
validation_blank_dir = os.path.join(validation_dir, 'Blank')

# Directory with our validation class2 pictures
validation_cancel_dir = os.path.join(validation_dir, 'Cancelled')

# Directory with our validation class3 pictures
validation_hand_dir = os.path.join(validation_dir, 'Handwritten')

# Directory with our validation class4 pictures
validation_print_dir = os.path.join(validation_dir, 'Printed')

# Directory with our test pictures
test_class_dir = os.path.join(test_dir, 'allclasses')

print(os.listdir(test_class_dir))

print('total training blank images:', len(os.listdir(train_blank_dir)))
print('total training cancelled images:', len(os.listdir(train_cancel_dir)))
print('total training handwritten images:', len(os.listdir(train_hand_dir)))
print('total training printed images:', len(os.listdir(train_print_dir)))

print('total validation blank images:', len(os.listdir(validation_blank_dir)))
print('total validation cancelled images:', len(os.listdir(validation_cancel_dir)))
print('total validation handwritten images:', len(os.listdir(validation_hand_dir)))
print('total validation printed images:', len(os.listdir(validation_print_dir)))
print('total test images:', len(os.listdir(test_class_dir)))


# All images will be rescaled by 1./255
train_datagen = ImageDataGenerator(rescale=1. / 255)
#train_datagen = ImageDataGenerator(rescale=1. / 255, rotation_range=40, horizontal_flip=True, fill_mode='nearest')#, rotation_range=40, zoom_range=0.2, shear_range=0.2, width_shift_range=0.2, height_shift_range=0.2
val_datagen = ImageDataGenerator(rescale=1. / 255)
test_datagen = ImageDataGenerator(rescale=1. / 255)

# training images
train_generator = train_datagen.flow_from_directory(
    train_dir,  # This is the source directory for training images
    target_size=(150, 150),  # All images will be resized to 150x150
    batch_size=1,
    class_mode='categorical',shuffle=False)#,save_to_dir='../data_repo')

# validation images
validation_generator = val_datagen.flow_from_directory(
    validation_dir,
    target_size=(150, 150),
    batch_size=1,
    class_mode='categorical',shuffle=False)

# test images
test_generator = test_datagen.flow_from_directory(
    test_dir,
    target_size=(150, 150),
    batch_size=1,
    class_mode='categorical',
    shuffle=False)


# the .flow() command below generates batches of randomly transformed images
# and saves the results to the `preview/` directory
X_train = []
Y_train = []
i = 0
for batch in train_generator:#.flow(x, batch_size=1):
    i += 1
    if i > 95:
        break  # otherwise the generator would loop indefinitely
    X_train.append(batch[0])
    Y_train.append(batch[1])
X_train = np.array(X_train)
Y_train = np.array(Y_train)
X_train = X_train.reshape((X_train.shape[0]*X_train.shape[1]), X_train.shape[2], X_train.shape[3], X_train.shape[4])
Y_train = Y_train.reshape((Y_train.shape[0]*Y_train.shape[1]), Y_train.shape[2])
X_train = X_train.reshape((X_train.shape[0], -1))
Y_train = np.argmax(Y_train, axis=1)
print(X_train.shape)
print(Y_train.shape)
#========================================
X_val = []
Y_val = []
i = 0
for batch in validation_generator:#.flow(x, batch_size=1):
    i += 1
    if i > 24:
        break  # otherwise the generator would loop indefinitely
    X_val.append(batch[0])
    Y_val.append(batch[1])
X_val = np.array(X_val)
Y_val = np.array(Y_val)
X_val = X_val.reshape((X_val.shape[0]*X_val.shape[1]), X_val.shape[2], X_val.shape[3], X_val.shape[4])
Y_val = Y_val.reshape((Y_val.shape[0]*Y_val.shape[1]), Y_val.shape[2])
X_val = X_val.reshape((X_val.shape[0], -1))
Y_val = np.argmax(Y_val, axis=1)
print(X_val.shape)
print(Y_val.shape)

'''
# get shape of feature matrix
print('Feature matrix shape is: ', X_train.shape)

# define standard scaler
ss = StandardScaler()
# run this on our feature matrix
bees_stand = ss.fit_transform(X_train)

pca = PCA(n_components=500)
# use fit_transform to run PCA on our standardized matrix
bees_pca = ss.fit_transform(bees_stand)
# look at new shape
print('PCA matrix shape is: ', bees_pca.shape)
'''


# Concatenate training and validation sets
X_train = np.concatenate((X_train, X_val))
Y_train = np.concatenate((Y_train, Y_val))
print('merged : ',X_train.shape)
print('merged : ',Y_train.shape)

skf = StratifiedKFold(n_splits=3, random_state=None, shuffle=False)

train_test_filename = "../data_kfold/{}.pkl"
count = 0
for train_index, test_index in skf.split(X_train, Y_train):
    print("TRAIN:", train_index, "TEST:", test_index)
    X_tr, X_te = X_train[train_index], X_train[test_index]
    y_tr, y_te = Y_train[train_index], Y_train[test_index]
    tmp_dict = {'X_tr':X_tr,'X_te':X_te,'y_tr':y_tr,'y_te':y_te}
    
    with open(train_test_filename.format(count), 'wb') as file:
        pickle.dump(tmp_dict, file)
    
    count += 1
    

