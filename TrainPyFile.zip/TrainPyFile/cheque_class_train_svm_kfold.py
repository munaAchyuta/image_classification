# -*- coding: utf-8 -*-
# author - U63411
from numpy.random import seed

seed(1)
import os
from tensorflow.keras import layers
from tensorflow.keras import Model
from tensorflow.keras.layers import BatchNormalization
from tensorflow.keras.optimizers import RMSprop, Adam, SGD
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.regularizers import l2
import numpy as np
import pandas as pd
from sklearn import svm, metrics, datasets
from sklearn.multiclass import OneVsRestClassifier
from sklearn.utils import Bunch
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.linear_model import SGDClassifier
import pickle

'''
batch_normalization = False

# Input feature map is 150x150x3: 150x150 for the image pixels, and 3 for R, G, and B
img_input = layers.Input(shape=(150, 150, 3))

# First convolution extracts 16 filters that are 3x3
# Convolution is followed by max-pooling layer with a 2x2 window
x = layers.Conv2D(16, 3, activation='relu')(img_input)
x = layers.MaxPooling2D(2)(x)

# Second convolution extracts 32 filters that are 3x3
# Convolution is followed by max-pooling layer with a 2x2 window
x = layers.Conv2D(32, 3, activation='relu')(x)
if batch_normalization: 
    x = BatchNormalization()(x)
x = layers.MaxPooling2D(2)(x)
x = layers.Dropout(0.4)(x)

# Third convolution extracts 64 filters that are 3x3
# Convolution is followed by max-pooling layer with a 2x2 window
x = layers.Conv2D(64, 3, activation='relu')(x)
if batch_normalization: 
    x = BatchNormalization()(x)
x = layers.MaxPooling2D(2)(x)
x = layers.Dropout(0.4)(x)

# Fourth convolution extracts 128 filters that are 3x3
# Convolution is followed by max-pooling layer with a 2x2 window
x = layers.Conv2D(128, 3, activation='relu')(x)
if batch_normalization: 
    x = BatchNormalization()(x)
x = layers.MaxPooling2D(2)(x)
x = layers.Dropout(0.4)(x)

# Fifth convolution extracts 256 filters that are 3x3
# Convolution is followed by max-pooling layer with a 2x2 window
x = layers.Conv2D(256, 3, activation='relu')(x)
if batch_normalization: 
    x = BatchNormalization()(x)
x = layers.MaxPooling2D(2)(x)
x = layers.Dropout(0.4)(x)

# Flatten feature map to a 1-dim tensor to add fully connected layers
x = layers.Flatten()(x)

# Create a fully connected layer with ReLU activation
x = layers.Dense(512, activation='relu')(x)
x = layers.Dropout(0.4)(x)

# Create output layer with 4 node(4-class) and sigmoid activation
#output = layers.Dense(4, activation='sigmoid')(x)
output = layers.Dense(4, kernel_regularizer=l2(0.01), activation='softmax')(x)

# Create model:
model = Model(img_input, output)

# Compile model
model.compile(#loss='categorical_crossentropy',
              #loss='kullback_leibler_divergence',
              loss='squared_hinge',
              optimizer=Adam(),
              #optimizer=RMSprop(lr=0.001),
              #optimizer='adadelta',
              #optimizer=SGD(lr=1e-4, momentum=0.9),
              metrics=['acc'])

model.summary()
'''

# Train model
train_test_filename = "../data_kfold/{}.pkl"
for k_fold in [0,1,2]:
    print("k-fold number : {}".format(k_fold))
    with open(train_test_filename.format(k_fold), 'rb') as file:
        pickle_model = pickle.load(file)
    X_train = pickle_model.get('X_tr')
    Y_train = pickle_model.get('y_tr')
    X_val = pickle_model.get('X_te')
    Y_val = pickle_model.get('y_te')

    clf = svm.LinearSVC(penalty='l2',loss='squared_hinge',C=0.1)
    #clf = SGDClassifier(random_state=42, max_iter=1000, tol=1e-3)
    clf.fit(X_train, Y_train)

    final_model = clf

    Y_pred = final_model.predict(X_val)

    print("Classification report for - \n{}:\n{}\n".format(final_model, metrics.classification_report(Y_val, Y_pred)))
    
    # Save to file in the current working directory
    pkl_filename = "../model/pickle_model_{}.pkl".format(k_fold)
    with open(pkl_filename, 'wb') as file:
        pickle.dump(final_model, file)

#import pickle
# Save to file in the current working directory
#pkl_filename = "../model/pickle_model.pkl"
#with open(pkl_filename, 'wb') as file:
#    pickle.dump(final_model, file)

# Load from file
#with open(pkl_filename, 'rb') as file:
#    pickle_model = pickle.load(file)