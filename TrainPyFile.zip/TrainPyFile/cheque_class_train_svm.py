# -*- coding: utf-8 -*-
# author - U63411
from numpy.random import seed

seed(1)
import os
from tensorflow.keras import layers
from tensorflow.keras import Model
from tensorflow.keras.layers import BatchNormalization
from tensorflow.keras.optimizers import RMSprop, Adam, SGD
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.regularizers import l2
import numpy as np
import pandas as pd
from sklearn import svm, metrics, datasets
from sklearn.multiclass import OneVsRestClassifier
from sklearn.utils import Bunch
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.linear_model import SGDClassifier

base_dir = os.path.join(os.path.dirname(__file__), '../Dataset_all_new')
train_dir = os.path.join(base_dir, 'train')
validation_dir = os.path.join(base_dir, 'validation')
test_dir = os.path.join(base_dir, 'test')

# Directory with our training class1 pictures
train_blank_dir = os.path.join(train_dir, 'Blank')

# Directory with our training class2 pictures
train_cancel_dir = os.path.join(train_dir, 'Cancelled')

# Directory with our training class3 pictures
train_hand_dir = os.path.join(train_dir, 'Handwritten')

# Directory with our training class4 pictures
train_print_dir = os.path.join(train_dir, 'Printed')

# Directory with our validation class1 pictures
validation_blank_dir = os.path.join(validation_dir, 'Blank')

# Directory with our validation class2 pictures
validation_cancel_dir = os.path.join(validation_dir, 'Cancelled')

# Directory with our validation class3 pictures
validation_hand_dir = os.path.join(validation_dir, 'Handwritten')

# Directory with our validation class4 pictures
validation_print_dir = os.path.join(validation_dir, 'Printed')

# Directory with our test pictures
test_class_dir = os.path.join(test_dir, 'allclasses')

print(os.listdir(test_class_dir))

print('total training blank images:', len(os.listdir(train_blank_dir)))
print('total training cancelled images:', len(os.listdir(train_cancel_dir)))
print('total training handwritten images:', len(os.listdir(train_hand_dir)))
print('total training printed images:', len(os.listdir(train_print_dir)))

print('total validation blank images:', len(os.listdir(validation_blank_dir)))
print('total validation cancelled images:', len(os.listdir(validation_cancel_dir)))
print('total validation handwritten images:', len(os.listdir(validation_hand_dir)))
print('total validation printed images:', len(os.listdir(validation_print_dir)))
print('total test images:', len(os.listdir(test_class_dir)))

'''
batch_normalization = False

# Input feature map is 150x150x3: 150x150 for the image pixels, and 3 for R, G, and B
img_input = layers.Input(shape=(150, 150, 3))

# First convolution extracts 16 filters that are 3x3
# Convolution is followed by max-pooling layer with a 2x2 window
x = layers.Conv2D(16, 3, activation='relu')(img_input)
x = layers.MaxPooling2D(2)(x)

# Second convolution extracts 32 filters that are 3x3
# Convolution is followed by max-pooling layer with a 2x2 window
x = layers.Conv2D(32, 3, activation='relu')(x)
if batch_normalization: 
    x = BatchNormalization()(x)
x = layers.MaxPooling2D(2)(x)
x = layers.Dropout(0.4)(x)

# Third convolution extracts 64 filters that are 3x3
# Convolution is followed by max-pooling layer with a 2x2 window
x = layers.Conv2D(64, 3, activation='relu')(x)
if batch_normalization: 
    x = BatchNormalization()(x)
x = layers.MaxPooling2D(2)(x)
x = layers.Dropout(0.4)(x)

# Fourth convolution extracts 128 filters that are 3x3
# Convolution is followed by max-pooling layer with a 2x2 window
x = layers.Conv2D(128, 3, activation='relu')(x)
if batch_normalization: 
    x = BatchNormalization()(x)
x = layers.MaxPooling2D(2)(x)
x = layers.Dropout(0.4)(x)

# Fifth convolution extracts 256 filters that are 3x3
# Convolution is followed by max-pooling layer with a 2x2 window
x = layers.Conv2D(256, 3, activation='relu')(x)
if batch_normalization: 
    x = BatchNormalization()(x)
x = layers.MaxPooling2D(2)(x)
x = layers.Dropout(0.4)(x)

# Flatten feature map to a 1-dim tensor to add fully connected layers
x = layers.Flatten()(x)

# Create a fully connected layer with ReLU activation
x = layers.Dense(512, activation='relu')(x)
x = layers.Dropout(0.4)(x)

# Create output layer with 4 node(4-class) and sigmoid activation
#output = layers.Dense(4, activation='sigmoid')(x)
output = layers.Dense(4, kernel_regularizer=l2(0.01), activation='softmax')(x)

# Create model:
model = Model(img_input, output)

# Compile model
model.compile(#loss='categorical_crossentropy',
              #loss='kullback_leibler_divergence',
              loss='squared_hinge',
              optimizer=Adam(),
              #optimizer=RMSprop(lr=0.001),
              #optimizer='adadelta',
              #optimizer=SGD(lr=1e-4, momentum=0.9),
              metrics=['acc'])

model.summary()
'''
# All images will be rescaled by 1./255
train_datagen = ImageDataGenerator(rescale=1. / 255)
val_datagen = ImageDataGenerator(rescale=1. / 255)
test_datagen = ImageDataGenerator(rescale=1. / 255)

# training images
train_generator = train_datagen.flow_from_directory(
    train_dir,  # This is the source directory for training images
    target_size=(150, 150),  # All images will be resized to 150x150
    batch_size=1,
    class_mode='categorical',shuffle=False)#,save_to_dir='../data_repo')

# validation images
validation_generator = val_datagen.flow_from_directory(
    validation_dir,
    target_size=(150, 150),
    batch_size=1,
    class_mode='categorical',shuffle=False)

# test images
test_generator = test_datagen.flow_from_directory(
    test_dir,
    target_size=(150, 150),
    batch_size=1,
    class_mode='categorical',
    shuffle=False)

# the .flow() command below generates batches of randomly transformed images
# and saves the results to the `preview/` directory
X_train = []
Y_train = []
i = 0
for batch in train_generator:#.flow(x, batch_size=1):
    i += 1
    if i > 95:
        break  # otherwise the generator would loop indefinitely
    X_train.append(batch[0])
    Y_train.append(batch[1])
X_train = np.array(X_train)
Y_train = np.array(Y_train)
X_train = X_train.reshape((X_train.shape[0]*X_train.shape[1]), X_train.shape[2], X_train.shape[3], X_train.shape[4])
Y_train = Y_train.reshape((Y_train.shape[0]*Y_train.shape[1]), Y_train.shape[2])
X_train = X_train.reshape((X_train.shape[0], -1))
Y_train = np.argmax(Y_train, axis=1)
print(X_train.shape)
print(Y_train.shape)
#========================================
X_val = []
Y_val = []
i = 0
for batch in validation_generator:#.flow(x, batch_size=1):
    i += 1
    if i > 24:
        break  # otherwise the generator would loop indefinitely
    X_val.append(batch[0])
    Y_val.append(batch[1])
X_val = np.array(X_val)
Y_val = np.array(Y_val)
X_val = X_val.reshape((X_val.shape[0]*X_val.shape[1]), X_val.shape[2], X_val.shape[3], X_val.shape[4])
Y_val = Y_val.reshape((Y_val.shape[0]*Y_val.shape[1]), Y_val.shape[2])
X_val = X_val.reshape((X_val.shape[0], -1))
Y_val = np.argmax(Y_val, axis=1)
print(X_val.shape)
print(Y_val.shape)

'''
# get shape of feature matrix
print('Feature matrix shape is: ', X_train.shape)

# define standard scaler
ss = StandardScaler()
# run this on our feature matrix
bees_stand = ss.fit_transform(X_train)

pca = PCA(n_components=500)
# use fit_transform to run PCA on our standardized matrix
bees_pca = ss.fit_transform(bees_stand)
# look at new shape
print('PCA matrix shape is: ', bees_pca.shape)
'''

# Train model
param_grid1 = [
  {'C': [1, 10, 100, 1000], 'kernel': ['linear']},
  {'C': [1, 10, 100, 1000], 'gamma': [0.001, 0.0001], 'kernel': ['rbf']},
 ]
param_grid2 = [{'C': [0.1, 1, 10, 100, 1000]}]

#svc = svm.SVC()
#clf = GridSearchCV(OneVsRestClassifier(svc), param_grid1, cv=3)
svc = svm.LinearSVC(penalty='l2',loss='squared_hinge')
clf = GridSearchCV(svc, param_grid2, cv=3, n_jobs=2)
#clf = svm.LinearSVC(penalty='l2',loss='squared_hinge','C'=0.1)
#clf = SGDClassifier(random_state=42, max_iter=1000, tol=1e-3)
#clf.fit(X_train, Y_train)

# View the accuracy score
print('Best score for training data:', clf.best_score_,"\n")

# View the best parameters for the model found using grid search
print('Best C:',clf.best_estimator_.C,"\n")
#print('Best Kernel:',clf.best_estimator_.kernel,"\n")
#print('Best Gamma:',clf.best_estimator_.gamma,"\n")

#final_model = clf
final_model = clf.best_estimator_

Y_pred = final_model.predict(X_val)

print("Classification report for - \n{}:\n{}\n".format(final_model, metrics.classification_report(Y_val, Y_pred)))

import pickle
# Save to file in the current working directory
pkl_filename = "../model/pickle_model.pkl"
with open(pkl_filename, 'wb') as file:
    pickle.dump(final_model, file)

# Load from file
#with open(pkl_filename, 'rb') as file:
#    pickle_model = pickle.load(file)
